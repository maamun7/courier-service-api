@extends('admin.layout.master')
@section('title') Admin Dashboard @stop

@section('page_name')
	Dashboard
	<small>Control panel</small>
@stop

@section ('breadcrumbs')
    <li class="active"> <a href="{!! route('admin.dashboard') !!}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
@stop

@section('content')
    <div class="row">

        <div class="col-lg-3 col-xs-6">
            <div class="info-box">
                <span class="info-box-icon bg-yellow">
                    <i class="icon ion-android-car"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">Total requests</span>
                    <span class="info-box-number total-request">
                        <small></small>
                    </span>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-xs-6">
            <div class="info-box">
                <span class="info-box-icon bg-aqua">
                    <i class="icon ion-checkmark-circled"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">Total trips</span>
                    <span class="info-box-number total-trip-completed">
                        <small></small>
                    </span>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-xs-6">
            <div class="info-box">
                <span class="info-box-icon bg-red">
                    <i class="ion ion-android-car"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">Today's total requests</span>
                    <span class="info-box-number today-trip-request">
                        <small></small>
                    </span>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-xs-6">
            <div class="info-box">
                <span class="info-box-icon bg-green">
                    <i class="icon ion-checkmark-circled"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">Today's total trips</span>
                    <span class="info-box-number today-trip-completed">
                        <small></small>
                    </span>
                </div>
            </div>
        </div>

    </div>
    <div class="box box-success">
        <div class="box-header with-border">
            <div class="pull-left">
                <div class="btn-toolbar">
                    Today's trips
                </div>
            </div>
        </div><!-- /.box-header -->
        <div class="box-body">
            <table class="table table-bordered table-condensed table-striped table-hover">
                <tr class="info">
                    <th>Sl.</th>
                    <th>Driver</th>
                    <th>Driver mobile</th>
                    <th>Payment method</th>
                    <th>Payment method code</th>
                    <th>Passenger</th>
                    <th>Passenger mob.</th>
                    <th>Pickup address</th>
                    <th>Drop address</th>
                    <th>Distance</th>
                    <th>Referral discount</th>
                    <th>Promo code discount</th>
                    <th>Credit deduct </th>
                    <th>Total rent</th>
                </tr>
                <tbody id="tripDataTable">

                </tbody>
                {{--Ajax row will load here--}}
            </table>
        </div>
        <div class="box-footer clearfix">
            <div class="pull-right">
                <ul class="pagination pagination-sm no-margin pull-right">

                </ul>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $.ajax
            ({
                type: "GET",
                url: "{!! route('admin.dashboard.top_total_items') !!}",
                data: {"_token": "{{ csrf_token() }}"},
                cache: false,
                contentType: 'application/json',
                dataType: 'json',
                success: function (response) {
                    $('.total-request').html(response.total_request);
                    $('.total-trip-completed').html(response.total_trip);
                    $('.today-trip-request').html(response.todays_request);
                    $('.today-trip-completed').html(response.todays_trip);
                },
                error: function (response, status, error) {

                }
            });
        });


        $(document).ready(function(){
            loadTripList(null);
        });

        function loadTripList(page) {
            $.ajax
            ({
                type: "GET",
                url: "{!! route('admin.dashboard.today_trip_list') !!}",
                data: {"_token": "{{ csrf_token() }}", "page": page},
                cache: false,
                contentType: 'application/json',
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    var items = response.data;
                    var singleRow = "";
                    if (items.length > 0) {
                        var k = ((( response.current_page * response.per_page) - response.per_page ) + 1);
                        for (var i = 0; i < items.length; i++) {

                             singleRow += "<tr>"
                                + "<td>" + k                                + "</td>"
                                + "<td>" + items[i].d_first_name            + "</td>"
                                + "<td>" + items[i].driver_mobile           + "</td>"
                                + "<td>" + items[i].payment_method          + "</td>"
                                + "<td>" + items[i].payment_method_code     + "</td>"
                                + "<td>" + items[i].p_first_name            + "</td>"
                                + "<td>" + items[i].mobile                  + "</td>"
                                + "<td>" + items[i].pickup_address          + "</td>"
                                + "<td>" + items[i].drop_address            + "</td>"
                                + "<td>" + items[i].distance_in_km          + "</td>"
                                + "<td>" + items[i].referral_code_amount    + "</td>"
                                + "<td>" + items[i].promo_code_amount       + "</td>"
                                + "<td>" + items[i].credit_amount           + "</td>"
                                + "<td>" + items[i].total_rent              + "</td>"
                            + "</tr>";

                            k++;
                        }

                        $('#tripDataTable').html(singleRow);

                        if (response.total > 0) {
                            $(".today-total-trip").html(response.total);

                            var paginationHtml = '';
                            //Previous page
                            if (response.prev_page_url == null) {
                                paginationHtml += '<li class="' + 'disabled' + '" onclick="">' + "<span>" + '«' + "</span>" + '</li>';
                            } else {
                                var prev_page_no = getQueryStringParameterByName(response.prev_page_url, 'page');
                                paginationHtml += '<li class="' + 'clickItem' + '" onclick="clickOnPage(' + prev_page_no +');">' + "<a href='#'>" + '«' + "</a>" + '</li>';
                            }

                            // All page (middle)
                            if (response.total <= response.per_page){
                                return;
                            }

                            var total_page = Math.ceil(response.total / response.per_page);
                            for (var j = 1; j <= total_page; j++) {
                                var displayItem = '';
                                var cssClass = 'clickItem';
                                if (j == response.current_page) {
                                    cssClass += " active";
                                }
                                paginationHtml += '<li class="' + cssClass + '" onclick="clickOnPage(' + j +');">' + "<a href='#'>" + j + "</a>" + '</li>';
                            }

                            //Next page
                            if (response.next_page_url == null) {
                                paginationHtml += '<li class="' + 'disabled' + '" onclick="">' + "<span>" + '»' + "</span>" + '</li>';
                            } else {
                                var next_page_no = getQueryStringParameterByName(response.next_page_url, 'page');
                                paginationHtml += '<li class="' + 'clickItem' + '" onclick="clickOnPage(' + next_page_no +');">' + "<a href='#'>" + '»' + "</a>" + '</li>';
                            }
                            $(".pagination").html(paginationHtml);

                        } else {
                            $(".today-total-trip").append('00');
                        }

                    } else {
                        //alert("Didn't found data");
                        singleRow += "<tr><td colspan='14'>No Data Found For Today</td></tr>";
                        $('#tripDataTable').html(singleRow);                        
                    }

                },
                error: function (response, status, error) {
                    alert(error);
                }
            });
        }

        function clickOnPage(page) {
            loadTripList(page);
        }

        function getQueryStringParameterByName(url, name) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                    results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

    </script>
@stop
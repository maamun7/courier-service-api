<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.5 -->
{!! Html::script('backend/bootstrap/js/bootstrap.min.js') !!}
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
{!! Html::script('backend/plugins/morris/morris.min.js') !!}
<!-- Sparkline -->
{!! Html::script('backend/plugins/sparkline/jquery.sparkline.min.js') !!}
<script src=""></script>
<!-- jvectormap -->
<script src="{!! asset('backend/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js') !!}"></script>
<script src="{!! asset('backend/plugins/jvectormap/jquery-jvectormap-world-mill-en.js') !!}"></script>
<!-- jQuery Knob Chart -->
<script src="{!! asset('backend/plugins/knob/jquery.knob.js') !!}"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>

<script src="{!! asset('backend/plugins/daterangepicker/daterangepicker.js') !!}"></script>
<script src="{!! asset('backend/plugins/timepicker/bootstrap-timepicker.min.js') !!}"></script>
<!-- datepicker -->
<!-- colorpicker -->
<script src="{!! asset('backend/plugins/colorpicker/bootstrap-colorpicker.js') !!}"></script>
<script src="{!! asset('backend/plugins/datepicker/bootstrap-datepicker.js') !!}"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="{!! asset('backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js') !!}"></script>
<!-- Slimscroll -->
<script src="{!! asset('backend/plugins/slimScroll/jquery.slimscroll.min.js') !!}"></script>
<!-- FastClick -->
<script src="{!! asset('backend/plugins/fastclick/fastclick.min.js') !!}"></script>
<!-- AdminLTE App -->
<script src="{!! asset('backend/dist/js/app.min.js') !!}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{!! asset('backend/dist/js/pages/dashboard.js') !!}"></script>
<!-- AdminLTE for demo purposes -->
<script src="{!! asset('backend/dist/js/demo.js') !!}"></script>
<!-- DataTables -->
<script src="{!! asset('backend/plugins/datatables/jquery.dataTables.min.js') !!}"></script>
<script src="{!! asset('backend/plugins/datatables/dataTables.bootstrap.min.js') !!}"></script>


<!-- metronic js file -->
<script src="{!! asset('backend/ezzyr_assets/vendors/base/vendors.bundle.js') !!}" type="text/javascript"></script>
<script src="{!! asset('backend/ezzyr_assets/demo/default/base/scripts.bundle.js') !!}" type="text/javascript"></script>
<!--end::Base Scripts -->
<!--begin::Page Snippets -->
<script src="{!! asset('backend/ezzyr_assets/app/js/dashboard.js') !!}" type="text/javascript"></script>
<script src="data_table.js" type="text/javascript"></script>
<!--end::Page Snippets -->
<!--begin::Page Vendors -->
<script src="//www.amcharts.com/lib/3/amcharts.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/serial.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/amstock.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/plugins/animate/animate.min.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/plugins/export/export.min.js" type="text/javascript"></script>
<script src="//www.amcharts.com/lib/3/themes/light.js" type="text/javascript"></script>
<!--end::Page Vendors -->
<!--begin::Page Resources -->
<script src="{!! asset('backend/ezzyr_assets/app/js/custom.js') !!}" type="text/javascript"></script>
<!-- metronic js file -->
<!-- DataTables -->
<script src="{!! asset('backend/plugins/datatables/jquery.dataTables.min.js') !!}"></script>
<script src="{!! asset('backend/plugins/datatables/dataTables.bootstrap.min.js') !!}"></script>
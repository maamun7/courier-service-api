<div id="m_ver_menu" class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark " data-menu-vertical="true" data-menu-scrollable="false" data-menu-dropdown-timeout="500" >
	<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">
		<li class="m-menu__item {{ setActive('admin') }}" aria-haspopup="true" >
			<a  href="{{ url('/admin') }}" class="m-menu__link ">
				<i class="m-menu__link-icon flaticon-line-graph"></i>
				<span class="m-menu__link-title">
					<span class="m-menu__link-wrap">
						<span class="m-menu__link-text">
							Dashboard
						</span>
					</span>
				</span>
			</a>
		</li>
		<li class="m-menu__item  m-menu__item--submenu {{ setActive('admin/users*') }} {{ setActive('admin/permission-group*') }} {{ setActive('admin/permission*') }} {{ setActive('admin/role*') }}" aria-haspopup="true"  data-menu-submenu-toggle="hover">
			<a  href="#" class="m-menu__link m-menu__toggle">
				<i class="m-menu__link-icon flaticon-layers"></i>
				<span class="m-menu__link-text">
					Role Management
				</span>
				<i class="m-menu__ver-arrow la la-angle-right"></i>
			</a>
			<div class="m-menu__submenu">
				<span class="m-menu__arrow"></span>
				<ul class="m-menu__subnav">
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/permission-group') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Permission Group
							</span>
						</a>
					</li>
					<li class="m-menu__item" aria-haspopup="true" >
						<a  href="{{ url('/admin/permission') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Permission
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/role') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Role
							</span>
						</a>
					</li>
				</ul>
			</div>
		</li>
		<li class="m-menu__item {{ setActive('admin/admin-users*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.admin-users') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-users"></i>
				<span class="m-menu__link-text">
					Admin User
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/passenger*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.passengers') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-male"></i>
				<span class="m-menu__link-text">
					Passenger
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/driver*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.drivers') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-wheelchair"></i>
				<span class="m-menu__link-text">
					Driver
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/merchant*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.merchants') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-diamond"></i>
				<span class="m-menu__link-text">
					Merchant
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/vehicle-types*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.vehicle-types') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-tags"></i>
				<span class="m-menu__link-text">
					Vehicle Type
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/vehicles*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.vehicles') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-truck"></i>
				<span class="m-menu__link-text">
					Vehicle
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/payment-method*') }}" aria-haspopup="true">
			<a  href="{{ url('/admin/payment-method') }}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-credit-card"></i>
				<span class="m-menu__link-text">
					Payment Method 
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/trips*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.trips') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-car"></i>
				<span class="m-menu__link-text">
					Trips
				</span>
			</a>
		</li>
		<li class="m-menu__item {{ setActive('admin/promocodes*') }}" aria-haspopup="true">
			<a  href="{!! route('admin.promocodes') !!}" class="m-menu__link">
				<i class="m-menu__link-icon fa fa-code"></i>
				<span class="m-menu__link-text">
					Promo codes
				</span>
			</a>
		</li>
		<li class="m-menu__item  m-menu__item--submenu {{ setActive('admin/quest') }}
            {{ setActive('admin/quest/show') }}" aria-haspopup="true"  data-menu-submenu-toggle="hover">
			<a  href="#" class="m-menu__link m-menu__toggle">
				<i class="m-menu__link-icon fa fa-cogs"></i>
				<span class="m-menu__link-text">
					Manage Quest
				</span>
				<i class="m-menu__ver-arrow la la-angle-right"></i>
			</a>
			<div class="m-menu__submenu">
				<span class="m-menu__arrow"></span>
				<ul class="m-menu__subnav">
					<li class="m-menu__item" aria-haspopup="true" >
						<a  href="{{ url('/admin/quest') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Quest List
							</span>
						</a>
					</li>				
				</ul>
			</div>
		</li>
		<li class="m-menu__item  m-menu__item--submenu {{ setActive('admin/view_report') }}
            {{ setActive('admin/passenger-report') }}
            {{ setActive('admin/driver-report') }}
            {{ setActive('admin/merchant-report') }}
            {{ setActive('admin/weekly-report') }}" aria-haspopup="true"  data-menu-submenu-toggle="hover">
			<a  href="#" class="m-menu__link m-menu__toggle">
				<i class="m-menu__link-icon fa fa-files-o"></i>
				<span class="m-menu__link-text">
					Reports
				</span>
				<i class="m-menu__ver-arrow la la-angle-right"></i>
			</a>
			<div class="m-menu__submenu">
				<span class="m-menu__arrow"></span>
				<ul class="m-menu__subnav">
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/passenger-report') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Passenger
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/driver-report') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Driver
							</span>
						</a>
					</li>	
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/merchant-report') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Merchant
							</span>
						</a>
					</li>					
				</ul>
			</div>
		</li>
		<li class="m-menu__item  m-menu__item--submenu {{ setActive('admin/merchant-report') }}
            {{ setActive('admin/weekly-report') }}" aria-haspopup="true"  data-menu-submenu-toggle="hover">
			<a  href="#" class="m-menu__link m-menu__toggle">
				<i class="m-menu__link-icon fa fa-files-o"></i>
				<span class="m-menu__link-text">
					Accounts Management
				</span>
				<i class="m-menu__ver-arrow la la-angle-right"></i>
			</a>
			<div class="m-menu__submenu">
				<span class="m-menu__arrow"></span>
				<ul class="m-menu__subnav">
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/accounts') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Merchant Accounts
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/weekly-report') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Merchant Weekly Settle
							</span>
						</a>
					</li>										
				</ul>
			</div>
		</li>
		<li class="m-menu__item  m-menu__item--submenu {{ setActive('admin/settings*') }}
            {{ setActive('admin/weekly-report') }}" aria-haspopup="true"  data-menu-submenu-toggle="hover">
			<a  href="#" class="m-menu__link m-menu__toggle">
				<i class="m-menu__link-icon fa fa-cogs"></i>
				<span class="m-menu__link-text">
					Settings
				</span>
				<i class="m-menu__ver-arrow la la-angle-right"></i>
			</a>
			<div class="m-menu__submenu">
				<span class="m-menu__arrow"></span>
				<ul class="m-menu__subnav">
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{!! route('admin.settings') !!}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								General Settings
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/emap') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								E-map
							</span>
						</a>
					</li>	
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/emap/e-zones') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								E-Zones
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/vehicle-make') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Vehicle Brands
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/vehicle-model') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Vehicle Models
							</span>
						</a>
					</li>
					<li class="m-menu__item " aria-haspopup="true" >
						<a  href="{{ url('/admin/vehicle-registration-city') }}" class="m-menu__link ">
							<i class="m-menu__link-bullet m-menu__link-bullet--dot">
								<span></span>
							</i>
							<span class="m-menu__link-text">
								Vehicle Registration City
							</span>
						</a>
					</li>
				</ul>
			</div>
		</li>		
	</ul>
</div>
<!-- END: Aside Menu -->